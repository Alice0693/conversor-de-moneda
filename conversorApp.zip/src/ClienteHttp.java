import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import com.google.gson.Gson;

public class ClienteHttp {

    public RespuestaMonedas obtenerTasas() {
        String url = "https://v6.exchangerate-api.com/v6/1b8708fa89134ea5ae0308dc/latest/USD";
        HttpClient cliente = HttpClient.newHttpClient();
        HttpRequest solicitud = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        try {
            HttpResponse<String> respuesta = cliente.send(solicitud, HttpResponse.BodyHandlers.ofString());
            Gson gson = new Gson();
            return gson.fromJson(respuesta.body(), RespuestaMonedas.class);
        } catch (Exception e) {
            System.out.println("Error al obtener tasas: " + e.getMessage());
            return null;
        }
    }
}

