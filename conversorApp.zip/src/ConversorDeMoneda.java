import java.util.Scanner;

public class ConversorDeMoneda {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ClienteHttp cliente = new ClienteHttp();
        RespuestaMonedas datos = cliente.obtenerTasas();

        if (datos == null) {
            System.out.println("No se pudieron obtener las tasas.");
            return;
        }

        System.out.println("********** Sea bienvenido/a al Conversor de Moneda =) **********");

        int opcion = 0;

        while (opcion != 11) {
            mostrarMenu();

            opcion = scanner.nextInt();

            if (opcion == 11) {
                System.out.println("Gracias por usar el conversor. ¡Hasta pronto!");
                break;
            }

            System.out.println();
            System.out.print("Ingrese el valor que deseas convertir: ");
            double monto = scanner.nextDouble();

            double resultado = 0;

            switch (opcion) {
                case 1:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("USD"), datos.getConversion_rates().get("ARS"));
                    System.out.println("\nEl valor " + monto + " [USD] corresponde al valor final de >>> " + resultado + " [ARS]");
                    break;
                case 2:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("ARS"), datos.getConversion_rates().get("USD"));
                    System.out.println("\nEl valor " + monto + " [ARS] corresponde al valor final de >>> " + resultado + " [USD]");
                    break;
                case 3:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("USD"), datos.getConversion_rates().get("BRL"));
                    System.out.println("\nEl valor " + monto + " [USD] corresponde al valor final de >>> " + resultado + " [BRL]");
                    break;
                case 4:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("BRL"), datos.getConversion_rates().get("USD"));
                    System.out.println("\nEl valor " + monto + " [BRL] corresponde al valor final de >>> " + resultado + " [USD]");
                    break;
                case 5:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("USD"), datos.getConversion_rates().get("COP"));
                    System.out.println("\nEl valor " + monto + " [USD] corresponde al valor final de >>> " + resultado + " [COP]");
                    break;
                case 6:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("COP"), datos.getConversion_rates().get("USD"));
                    System.out.println("\nEl valor " + monto + " [COP] corresponde al valor final de >>> " + resultado + " [USD]");
                    break;
                case 7:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("USD"), datos.getConversion_rates().get("BOB"));
                    System.out.println("\nEl valor " + monto + " [USD] corresponde al valor final de >>> " + resultado + " [BOB]");
                    break;
                case 8:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("BOB"), datos.getConversion_rates().get("USD"));
                    System.out.println("\nEl valor " + monto + " [BOB] corresponde al valor final de >>> " + resultado + " [USD]");
                    break;
                case 9:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("USD"), datos.getConversion_rates().get("CLP"));
                    System.out.println("\nEl valor " + monto + " [USD] corresponde al valor final de >>> " + resultado + " [CLP]");
                    break;
                case 10:
                    resultado = convertirMoneda(monto, datos.getConversion_rates().get("CLP"), datos.getConversion_rates().get("USD"));
                    System.out.println("\nEl valor " + monto + " [CLP] corresponde al valor final de >>> " + resultado + " [USD]");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }

            System.out.println("\n************************************************************");
        }
    }

    public static double convertirMoneda(double monto, double tasaOrigen, double tasaDestino) {
        return monto * (tasaDestino / tasaOrigen);
    }

    public static void mostrarMenu() {
        System.out.println("Sea bienvenido(a) al Conversor de Moneda =)");
        System.out.println(); // línea en blanco entre mensaje y menú
        System.out.println("1) Dólar => Peso argentino");
        System.out.println("2) Peso argentino => Dólar");
        System.out.println("3) Dólar => Real brasileño");
        System.out.println("4) Real brasileño => Dólar");
        System.out.println("5) Dólar => Peso colombiano");
        System.out.println("6) Peso colombiano => Dólar");
        System.out.println("7) Dólar => Boliviano boliviano");
        System.out.println("8) Boliviano boliviano => Dólar");
        System.out.println("9) Dólar => Peso chileno");
        System.out.println("10) Peso chileno => Dólar");
        System.out.println("11) Salir");
        System.out.println("Seleccione una opción válida:");
        System.out.println("************************************************************");
    }
}











